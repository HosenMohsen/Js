function select(objet) {
    let x = document.querySelector(objet);
    console.log(x);
}

select("#France");